package uk.ac.tees.p4072699.dogmapp;


public class Friend {
}
